import { auth, db } from "./admin.js";

/**
 * RBAC Middleware (FinTech-grade gatekeeper)
 */
export async function authMiddleware(req, res, next) {
  try {
    // 1. Extract token
    const header = req.headers.authorization;

    if (!header || !header.startsWith("Bearer ")) {
      return res.status(401).json({
        error: "Missing Authorization Bearer token",
      });
    }

    const idToken = header.split("Bearer ")[1];

    // 2. Verify Firebase token
    const decoded = await auth().verifyIdToken(idToken);

    const email = decoded.email || decoded.uid;

    if (!email) {
      return res.status(401).json({
        error: "Invalid token: missing email/uid",
      });
    }

    // 3. Lookup RBAC user
    const userDoc = await db().collection("users").doc(email).get();

    if (!userDoc.exists) {
      return res.status(403).json({
        error: "Access denied: user not found in RBAC system",
      });
    }

    const user = userDoc.data();

    // 4. Status check
    if (user.status !== "active") {
      return res.status(403).json({
        error: "User is not active",
      });
    }

    // 5. Attach user context
    req.user = {
      email,
      role: user.role || "user",
    };

    // 6. Continue
    next();
  } catch (err) {
    console.error("AUTH_MIDDLEWARE_ERROR:", err);

    return res.status(401).json({
      error: "Unauthorized",
    });
  }
}

/**
 * Role-based guard (optional extension)
 */
export function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthenticated" });
    }

    if (req.user.role !== role && req.user.role !== "admin") {
      return res.status(403).json({ error: "Forbidden (RBAC)" });
    }

    next();
  };
}